const Wrap = (props) => {
    return(props.children)
}

export default Wrap;